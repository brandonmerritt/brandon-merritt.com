# CSS
===============
## Dependencies
I believe we should make use of SASS, Compass, Susy for layout, and our own Style Hatch mixin library. 

## Relative Sizing
From what I see on sassaparilla, it looks like they use the Vertical Rhythm features of Compass for most of their layout. *[More on Vertical Rhythm](http://atendesigngroup.com/blog/vertical-rhythm-compass)*. They set font sizes using `@adjust-font-size-to(24px);` They set default leading and trailing to elements based on the line-height. eg.

	@include padding-leader(4);
	@include padding-trailer(2);
	@include trailer(6);
	

Which basically means add 4 lines above as padding, 2 lines below as padding, and 6 lines below as margin. Relative to the current line-height. You can also set using:

	margin: 0 0 rhythm(4, 16px) 0;

Which means 4 lines below based on font size. Or for a whole section adjust any of these settings using:

	@include adjust-leading-to(2);

For example, they adjust leading to 2 on the body in their print stylesheet to save space. One declaration and all of the spacing is adjusted accordingly.

For the cases where this type of typographic rhythm based spacing doesn't work, they created a mixin that will convert px to ems using some math with the base font size. They use it mostly for media queries such as: 

	@media screen and (min-width: em-font(800px)) {
		.container {
			min-width: em-font(780px);
		}
	}

The last thing that their framework doesn't really address is how they set their grid/columns for more complex layouts. I'm assuming they may set the width of container elements using the same `em-font()` function. Or using percentage widths. Susy could be a good option to provide an easy way to add flexible columns using a simple sass mixin. It also works very well with the Compass vertical rhythm stuff, which Sassaparilla uses pretty heavily as well.

Overall, I think the key is building out a solid flexible foundation. Flexible typography, flexible rhythm, and a flexible grid. Setting these up up front may take a little bit more planning and tweaking before starting, but if done correctly things should just "look right" with very little specific element styles. If something looks wrong; adjust font size, leading, trailing, rhythm, etc. In my experience, it seems that margins padding and so on usually look best when proportionate to the font-size or line-height anyway. For example, margin after a paragraph equal to two lines of text is easily achieved with `@include trailer(2);` which ends up being much more flexible than `margin-bottom: 24px;` in the long run. Whether it be media queries or just adjusting the overall rhythm, sizing, or proportions because it feels "off". It really comes down to building a mini style-guide or framework at the beginning of every project. Creating rules of proportion as opposed to exact rules of size.

I think Sassaparilla is a good framework fffunction built for internal use. There's not too much to it beyond sass and compass. Just a couple functions and their own custom reset and base styling. Plus some CSS guidelines they adhere to. I think it's a great example of what we could do ourselves for a style hatch theme framework. We can pull our favorite functions from across some different frameworks, plus write our own. Especially since we'll always be working within the tumblr framework.

## Extending
If we were to set all color variables in a "_colors.scss" file. We could apply those variables to extends selectors such as: 
`%text-color { color: $black; }`
(The placeholder selector name should match that used as the meta variable for the customize menu)
then use:
`body { @extend %text-color; }`
When the final CSS file is compiled, every single time a color selector is extended, it is added to one long comma separated CSS rule. If we used this for every instance of every single user-editable color used, we would only have to pull that one long declaration instead of compiling our own. We could then delete all of the extends to clean up our CSS and only leave the color declarations in the header of the HTML.


## Modularize Mixins
All previously used CSS snippets should be converted into a SASS mixin library. For example, instead of looking back in an old theme and pulling the CSS and markup for dark-social icons we should have standardized markup for all social links plus a simple mixin `@include dark-social;`. This should all be referencable via documentation.

# Markup
===============
As we've talked about before, it would be great if we could even standardize the markup and classes. I think we should definitely standardize the meta data for all of the user customization options. 

## Modularization & Documentation
It would be very useful for us to create documentation to show how we achieved certain things in the past. For example the "dark social icons" customization option. Let's say I wanted to include that in my theme. It would be great to look in the documentation and find that rule and the markup and CSS that was used to achieve that feature before. Maybe it could be dropped in as is, with some slight styling tweaks on top. Basically modularizing the code.

Not only would this be useful for referencing and using things done in the past, but also for updating and optimizing those things. If they're all pulled from one central modular piece, we can improve upon that piece and "push" it out to all of our themes.

Also, writing new little snippets could be done quickly and easily to be referenced and used in an upcoming theme. For example, I believe Jonathan just wrote a better way of pulling in Instagram photos and the likes and comment associated with those. It would be ideal if that little module was available to reference and possibly even drop into old themes as an update. Another example would be the CSS3 spinner. Instead of writing that into the Patchwork theme, it could have been created as a new style hatch module as soon as I ran across it. That way it could be referenced and used by all much more easily. In the process it would also be tied in with our universal meta options. Eg. the spinner's primary color accent and background subtle.

### KSS
KSS could be a good option for our documentation. The ultimate example being githubs [style guide](https://github.com/styleguide/css) created using [KSS](https://github.com/kneath/kss). I haven't looked into it enough to fully understand how it could work with Tumblr. I think we should have documentation of modular pieces of code, along with a visual interactive example of that element. For example, the dark social icons should show the markup, the css, and a live example.

The only issue I see us running into there would be the ability to use Tumblr's templating language in the documentation. It seems somewhat inefficient to markup a whole index page and then go back through and rewrite that markup with tumblr code. For example, the instagram post rendering "module". We could do static code to show what it looks like, but what would be most useful is if we could work on a live version using actual tumblr code.

### Boilerplate
A few options I see:

1. A single markup file that we don't change, only the stylesheet.
2. The documentation somehow processes tumblr code to give live examples.
3. The documentation includes standard markup + tested tumblr markup for that exact same "use case". We could possibly just comment out the tumblr code while still in dev. Once going to production, remove tumblr code from comments, adapt to match tweaks to static markup, then delete all static markup.

Option 3 seems easiest off the bat. It would make more sense to me to be coding *both* the static and the tumblr markup at the same time as I'm going through. For example, I'm working on a new theme and I want to add the instagram module. I drop that in (whether manually from documentation or dynamically?). I decide I want to remove comments and likes. At that time I would delete the comments and likes from the static markup *as well* as the tumblr code that is commented out just above/below that block. To test, uncomment all tumblr code, comment out all static, upload to testing tumblr instance.

We should include all meta-data and user customization options in that same markup file. Those should remain constant across all themes. Meaning, the naming shouldn't change. If you don't want to use an option, comment it out or delete it for production. That way from the start you will have every option needed, as well as the latest/best/tested implimentation of that option. If we need to add an option, it should be added as a module to be included in the boilerplate from that point forward.

### Compiling
Compiling interactive documentation from one set of "partials" seems ideal to me. Something similar to Jekyll. A folder or folders of modules with markup, tumblr markup, css, or javascript. Each modularized so that they can be added, updated, individually. When saved the documentation example is updated to that latest partial.

In some ways, it seems to make sense to have the modules importable with something almost like tumblr or liquid templating language. eg. `{{ dark-social }}`. The problem we could run into there is if you want to import that module but make changes. In that case it may be easier to just copy and paste the markup with accompanying tumblr markup in comments and then tweak those. CSS would have to be copied over as well. This example may not be the best, because actually the markup shouldn't change. We should have a standardized way of including the markup for social links. The modules should be CSS or SASS mixins that give the look you are looking for. e.g.
	
	div.social-links {
		@include dark-social;
	}

In every case we should try to keep markup as standardized as possible so that stylisitc changes can be made with our own StyleHatch SASS mixin library.

# Javascript
================
## Modularize!
We're going to use Bower to modularize and manage dependencies for our projects.

# Example Module
================
## Light Social Icons

**along with the code below there would be a live interactive example of the element**

### Static HTML

<!-- Social Links -->
	   <div class="social-links">
	     <a href="https://twitter.com/stylehatch" class="twitter-follow-button" data-show-count="false">Follow @stylehatch</a>
	     <ul>
	       <li class="social_facebook"><a href="#" class="ir">Facebook</a></li>
	       <li class="social_twitter"><a href="#" class="ir">Twittr</a></li>
	       <li class="social_flickr"><a href="#" class="ir">Flickr</a></li>
	       <li class="social_vimeo"><a href="#" class="ir">Vimeo</a></li>
	       <li class="social_dribbble"><a href="#" class="ir">Dribbble</a></li>
	       <li class="social_delicious"><a href="#" class="ir">Delicious</a></li>
	       <li class="social_lastfm"><a href="#" class="ir">Last.fm</a></li>
	     </ul>
	   </div>
	   
### Tumblr Markup

	<!--        
	{block:IfShowSocialLinks}
     <div class="social-links">
       {block:IfTwitterWidgetEmbed}
       {text:Twitter Widget Embed}
       {/block:IfTwitterWidgetEmbed}
       {block:IfNotTwitterWidgetEmbed}
       {block:Twitter}
       <a href="https://twitter.com/{TwitterUsername}" class="twitter-follow-button" data-show-count="false" data-lang="en">Follow @{TwitterUsername}</a>
       {/block:Twitter}
       {/block:IfNotTwitterWidgetEmbed}
       <ul>
         {block:IfBehanceURL}<li class="social_behance"><a href="{text:Behance URL}" class="ir">Behance</a></li>{/block:IfBehanceURL}
         {block:IfCargoURL}<li class="social_cargo"><a href="{text:Cargo URL}" class="ir">Cargo</a></li>{/block:IfCargoURL}
         {block:IfDeliciousURL}<li class="social_delicious"><a href="{text:Delicious URL}" class="ir">Delicious</a></li>{/block:IfDeliciousURL}
         {block:IfDribbbleURL}<li class="social_dribbble"><a href="{text:Dribbble URL}" class="ir">Dribbble</a></li>{/block:IfDribbbleURL}
         {block:IfEtsyURL}<li class="social_etsy"><a href="{text:Etsy URL}" class="ir">Etsy</a></li>{/block:IfEtsyURL}
         {block:IfFacebookURL}<li class="social_facebook"><a href="{text:Facebook URL}" class="ir">Facebook</a></li>{/block:IfFacebookURL}
         {block:IfFFFFoundURL}<li class="social_ffffound"><a href="{text:FFFFound URL}" class="ir">FFFFound</a></li>{/block:IfFFFFoundURL}
         {block:IfFlickrURL}<li class="social_flickr"><a href="{text:Flickr URL}" class="ir">Flickr</a></li>{/block:IfFlickrURL}
         {block:IfFormspringURL}<li class="social_formspring"><a href="{text:Formspring URL}" class="ir">Formspring</a></li>{/block:IfFormspringURL}
         {block:IfForrstURL}<li class="social_forrst"><a href="{text:Forrst URL}" class="ir">Forrst</a></li>{/block:IfForrstURL}
         {block:IfFoursquareURL}<li class="social_foursquare"><a href="{text:Foursquare URL}" class="ir">Foursquare</a></li>{/block:IfFoursquareURL}
         {block:IfGithubURL}<li class="social_github"><a href="{text:Github URL}" class="ir">Github</a></li>{/block:IfGithubURL}
         {block:IfGooglePlusURL}<li class="social_google"><a href="{text:Google Plus URL}" class="ir">Google Plus</a></li>{/block:IfGooglePlusURL}
         {block:IfInstagramURL}<li class="social_instagram"><a href="{text:Instagram URL}" class="ir">Instagram</a></li>{/block:IfInstagramURL}
         {block:IfLastFMURL}<li class="social_lastfm"><a href="{text:LastFM URL}" class="ir">LastFM</a></li>{/block:IfLastFMURL}
         {block:IfLinkedinURL}<li class="social_linkedin"><a href="{text:Linkedin URL}" class="ir">Linkedin</a></li>{/block:IfLinkedinURL}
         {block:IfPinterestURL}<li class="social_pinterest"><a href="{text:Pinterest URL}" class="ir">Pinterest</a></li>{/block:IfPinterestURL}
         {block:IfQuoraURL}<li class="social_quora"><a href="{text:Quora URL}" class="ir">Quora</a></li>{/block:IfQuoraURL}
         {block:IfRdioURL}<li class="social_rdio"><a href="{text:Rdio URL}" class="ir">Rdio</a></li>{/block:IfRdioURL}
         {block:IfSkypeURL}<li class="social_skype"><a href="{text:Skype URL}" class="ir">Skype</a></li>{/block:IfSkypeURL}
         {block:IfSlideshareURL}<li class="social_slideshare"><a href="{text:Slideshare URL}" class="ir">Slideshare</a></li>{/block:IfSlideshareURL}
         {block:IfSoundcloudURL}<li class="social_soundcloud"><a href="{text:Soundcloud URL}" class="ir">Soundcloud</a></li>{/block:IfSoundcloudURL}
         {block:IfSpotifyURL}<li class="social_spotify"><a href="{text:Spotify URL}" class="ir">Spotify</a></li>{/block:IfSpotifyURL}
         {block:IfStumbledUponURL}<li class="social_stumbledupon"><a href="{text:Stumbled Upon URL}" class="ir">Stumbled</a></li>{/block:IfStumbledUponURL}
         {block:IfTwitterURL}<li class="social_twitter"><a href="{text:Twitter URL}" class="ir">Twitter</a></li>{/block:IfTwitterURL}
         {block:IfVimeoURL}<li class="social_vimeo"><a href="{text:Vimeo URL}" class="ir">Vimeo</a></li>{/block:IfVimeoURL}
         {block:IfWebsiteURL}<li class="social_website"><a href="{text:Website URL}" class="ir">Website</a></li>{/block:IfWebsiteURL}
         {block:IfYouTubeURL}<li class="social_youtube"><a href="{text:YouTube URL}" class="ir">YouTube</a></li>{/block:IfYouTubeURL}
         {block:IfEmailAddress}<li class="social_email"><a href="mailto:{text:Email Address}" class="ir">Email Address</a></li>{/block:IfEmailAddress}
       </ul>
     </div>
     {/block:IfShowSocialLinks} 
	-->
	<!-- End Social Links -->

### SASS 

	  @mixin social-links-light($size) {
	    margin: $columnGutters $columnGutters*-1;
	    padding: 0 $columnGutters $columnGutters;
	    border-bottom: 1px dotted $grayLighter;
	
	    ul {
	      @include clearfix;
	      margin: 8px 0 0 0;
	
	      li {
	        float: left;
	        a {
	          @extend %image-replace;
	          display: block;
	          width: $size;
	          height: $size;
	          margin: 0 2px;
	          background-image: url(../img/social_icons-black.png);
	          background-repeat: no-repeat;
	          opacity: .25;
	          &:hover {
	            opacity: .8;
	          }
	        }
	        // social media icon image replacements
	        &.social_behance a { background-position: 0 0; }
	        &.social_cargo a { background-position: -20px 0; }
	        &.social_delicious a { background-position: -(40px) 0; }
	        &.social_digg a { background-position: -60px 0; }
	        &.social_dribbble a { background-position: -80px 0; }
	        &.social_ember a { background-position: -100px 0; }
	        &.social_etsy a { background-position: -120px 0; }
	        &.social_facebook a { background-position: -140px 0; }
	        &.social_ffffound a { background-position: -160px 0; }
	        &.social_flickr a { background-position: -180px 0; }
	        &.social_gowalla a { background-position: -200px 0; }
	        &.social_lastfm a { background-position: -220px 0; }
	        &.social_linkedin a { background-position: -240px 0; }
	        &.social_skype a { background-position: -260px 0; }
	        &.social_slideshare a { background-position: -280px 0; }
	        &.social_stumbledupon a { background-position: -300px 0; }
	        &.social_twitter a { background-position: -320px 0; }
	        &.social_vimeo a { background-position: -340px 0; }
	        &.social_youtube a { background-position: -360px 0; }
	        &.social_email a { background-position: -380px 0; }
	        &.social_forrst a { background-position: -400px 0; }
	        &.social_soundcloud a { background-position: -420px 0; }
	        &.social_formspring a { background-position: -440px 0; }
	        &.social_foursquare a { background-position: -460px 0; }
	        &.social_deviantart a { background-position: -480px 0; }
	        &.social_website a { background-position: -500px 0; }
	        &.social_rdio a { background-position: -520px 0; }
	        &.social_myspace a { background-position: -540px 0; }
	        &.social_google a { background-position: -560px 0; }
	        &.social_spotify a { background-position: -580px 0; }
	        &.social_pinterest a { background-position: -600px 0; }
	        &.social_github a { background-position: -620px 0; }
	        &.social_quora a { background-position: -640px 0; }
	        &.social_instagram a { background-position: -660px 0; }
	      }
	    }
	  }

####NOTE

From the example you will notice that there are variables like `$columnGutters` and `$grayLighter` used within the mixin. We would have to think through this during the process of standardizing the boilerplate. Those margins could be local to the mixin, *or* it's possible that every single theme has those variables that must be set from the start. Especially for colors, every single theme should use color variables like `$primary` or `$accent`. Their value will be set differently within each theme's `_settings.scss` or `_colors.scss` partials. The value changes, but the variable always stays the same, that way our mixins don't break because of variables that don't exist. Same goes for user-customization options. They should always be named the same so that the if statements don't break with a new theme.