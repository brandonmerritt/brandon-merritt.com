/*jshint asi: true, browser: true, curly: true, eqeqeq: true, forin: false, immed: false, newcap: true, noempty: true, strict: true, undef: true */
/*global jQuery: false, log: true, StyleHatch: true, Tumblr: true, DISQUS: true, gapi: true */

(function( window, $, undefined ){
	'use strict';

  var $hero = $('header.hero');
  var $nav = $('nav.pages');
  var $main = $('#main');

  $('body,html').scrollTop(0);

  StyleHatch.skipHeader = true;
  if(StyleHatch.skipHeader === true){
    if(window.location.pathname !== '/' || $('body').hasClass('permalink-page')){

      //log('skip header');
      $(window).scrollTop($('nav.pages').offset().top);
    }
  }

  StyleHatch.navBottom = 0;

  $(window).resize(function(){

    // Offset the bottom of the hero container based off of the nav height
    var navHeight = $nav.outerHeight();
    $('.hero .container-box').css({
      'bottom': navHeight + 40
    });


    // If the contents of the hero are too large to show,
    // push the navigation down and set a larger height
    var cHeight = $('.hero .container').height();
    var cBoxTop = parseInt($('.hero .container-box').css('top').replace('px', ''));
    var cBoxBottom= parseInt($('.hero .container-box').css('bottom').replace('px', ''));

    if($('.hero .container').height() > ($(window).height() - cBoxTop - cBoxBottom) ){
      var heroHeight =  cHeight + cBoxTop + cBoxBottom;

      $hero.height(heroHeight);

      StyleHatch.navBottom = $(window).height() - heroHeight;
      $nav.css({
        'bottom': StyleHatch.navBottom
      });
    } else {
      $hero.css({
        'height': '100%'
      });
      StyleHatch.navBottom = 0;
      $nav.css({
        'bottom': StyleHatch.navBottom
      });
    }


    // If the page has very few posts, make sure the min-height on the posts is set
    // so that you can scroll to the bottom / nav to the top
    var mainPaddingTop = parseInt($main.css('padding-top').replace('px', ''));
    var mainPaddingBottom = parseInt($main.css('padding-bottom').replace('px', ''));

    if(($main.height() + mainPaddingTop + mainPaddingBottom + $nav.outerHeight()) < $(window).height()){
      var mainHeight = $(window).height() - $nav.outerHeight();

      if($main.height() !== mainHeight){
        $main.css({
          'min-height': mainHeight
        });
      }
    }

    var navWidth = $nav.width();
    var titleWidth = $nav.find('h1 a').width();
    var pagesWidth = $nav.find('ul').width();

    if(navWidth <= titleWidth + pagesWidth){
      $nav.addClass('stacked');
    } else {
      $nav.removeClass('stacked');
    }

  });
  $(window).resize();


  // SCRIPTS TO LOAD ON LIVE BLOGS, NOT INSIDE CUSTOMIZE MENU
  // --------------------------------------------------
  $.getScript('http://platform.twitter.com/widgets.js');
  if(!StyleHatch.customizeMode){
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
      po.src = 'https://apis.google.com/js/plusone.js';
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  }

  // BROWSER DETECTION
  // --------------------------------------------------

  // iOS detect
  if( navigator.platform.indexOf( "iPhone" ) !== 0 && navigator.platform.indexOf( "iPad" ) !== 0  && navigator.platform.indexOf( "iPod" ) !== 0  ){
      StyleHatch.iOS = false;
  } else {
      StyleHatch.iOS = true;
  }

  // Firefox detect
  StyleHatch.firefox = testCSS('MozBoxSizing');
  function testCSS(prop) {
      return prop in document.documentElement.style;
  }

  // Default Tumblr bar src




  // JS HISTORY
  // All article loads / calls are routed though
  // --------------------------------------------------

  //Setup History to call on infinite-scroll
  var History = window.History;
  if(!History.enabled){
      return false;
  }
  // Handles all of the routing
  History.Adapter.bind(window,'statechange',function(){
    var State = History.getState();

    StyleHatch.postID = State.data.id;
    StyleHatch.url = State.url;

    if(typeof StyleHatch.postID !== 'undefined'){
      $('article[data-postid="' + StyleHatch.postID + '"]').loadArticle();
    } else {
      closeViewer();
    }

  });
  // set default base url, this gets overwritten by infinte scroll paging
  StyleHatch.baseURL = window.location.pathname;
  StyleHatch.openExpand = null;
  StyleHatch.currentArticle = null;


  // COMMON THEME SPECIFIC JQUERY PLUGINS
  // Some things inside will need to change on a theme to theme basis
  // --------------------------------------------------

  // $.swapHighRes();
  // Assign to photo to swap out for highres if over 500px
  $.fn.swapHighRes = function(){
    var $article = $(this);
    // the calculation might and path to high res might change from theme to theme
    var $container = $article;
    var $image = $article.find('header img');

    // stop the proces if it has already been swapped, useful for resize events
    if($image.attr('data-highres-swap')) {
      return true;
    }
    var articleWidth = $container.width();
    if(articleWidth > 500){
      // make sure highres exists
      if($image.attr('data-highres')){
        $image.attr('src', $image.attr('data-highres'));
        $image.attr('data-highres-swap', true);
      }
    }
  }

  // $.swapHighRes();
  // a single, basic plugin to handle all the theme specific setup of the share plugin
  // this prevents the same code pasted in multiple places for index, permalink, infinite scroll
  $.fn.setupTumblrShare = function () {
    return this.each(function () {
      var $share = $(this);

      // only render the buttons, look up images, twitter user etc if the div is empty
      // prevents it from being called multiple times even though the jQuery plugin
      // can not be duplicated
      if( $share.is(':empty') ){
        // tumblrShare vars
        // permalink
        var $article = $share.closest('article');
        var sharePermalink = $article.attr('data-permalink');

        // smart (by post type) check for images in the post
        var $postImages = $article.find('section img, header img');
        var pinMedia = '';
        var showPinterest = false;
        if($postImages.length > 0){
          // if there are images show pinterest and assign the first image to the media
          showPinterest = true;
          if( $postImages.first().attr('data-highres') ){
            pinMedia = $postImages.first().attr('data-highres');
          } else {
            pinMedia = $postImages.first().attr('src');
          }
        }

        // set via to Twitter user only if they have Twitter setup
        var via = '';
        if(StyleHatch.twitterUser){
          via = StyleHatch.twitterUser;
        }

        $share.tumblrShare({
          url: sharePermalink,
          media: pinMedia,
          via: via,
          size: 'horizontal',
          pinterest: showPinterest,
          onComplete: function(){
            try{
              gapi.plusone.go();
            } catch(err){
              //log('not there', err);
            }
            $.getScript('http://platform.twitter.com/widgets.js');
            $.getScript('http://assets.pinterest.com/js/pinit.js');
          }
        });

      }

    });
  };

  window.getQueryVariable = function(str, variable) {
    var query = str;
    var vars = query.split("&");
    for (var i=0;i<vars.length;i++) {
      var pair = vars[i].split("=");
      if(pair[0] === variable){return pair[1];}
    }
    return(false);
  };



  // ARTICLE INIT
  // --------------------------------------------------
  $.fn.initArticle = function () {
    // Broad initialization to articles
    var $allArticles = $('article');

    // Specific initialization to articles
    return this.each(function (i) {
      var $article = $(this);
      var isViewer = ( $article.parent().attr('id') === 'viewerContainer' ) ? true : false;

      // swap out images for high res
      if($article.is('.photo')){
        $article.swapHighRes();
        $article.find('a.highres').colorbox({
          photo:true,
          maxHeight:'90%',
          maxWidth:'90%'
        });
      }

      if(isViewer){
        // fitVids! Yay!
        if($article.is('.text, .photo, .photoset, .link, .quote, .video, .ask')){
          $article.fitVids();
        }
      }
      $article.find('section').fitVids();

      if( $.trim($article.find('section').html()) === '' ){
        $article.find('section').empty();
      }
      if( $.trim($article.find('.track-details').html()) === '' ){
        $article.find('.track-details').empty();
      }

      // Photoset Grid
      var $photosetGrid = $article.find('.photoset-grid');
      if($photosetGrid.length > 0){

        // Reset the photo grid
        if($photosetGrid.find('.photoset-row').length !== 0){
          var $images = $photosetGrid.find('img').clone();
          $photosetGrid.empty();
          $photosetGrid.addClass('visuallyhidden');
          $photosetGrid.removeAttr('data-width');
          $images.appendTo($photosetGrid);
        }

        // Apply Photoset grid
        $photosetGrid.find('img').imagesLoaded(function( $images, $proper, $broken ){

          $photosetGrid.photosetGrid({
            layout: $photosetGrid.attr('data-photoset-layout'),
            width: '100%',
            gutter: '0px',
            highresLinks: true,
            lowresWidth: 320,
            rel: $photosetGrid.attr('data-photoset-id'),
            onInit: function(){},
            onComplete: function(){
                $photosetGrid.removeClass('visuallyhidden');
                $(window).trigger('resize');
                $posts.isotope('layout');
            }
          });
        });


      }

      if(!StyleHatch.indexPage){
        // paths to share buttons
        var $shareButtons = $article.find('.share-buttons');
        $shareButtons.setupTumblrShare();
      }

    });
  }
  $('.article-box').initArticle();

  // Show / hide article hover
  $.fn.articleHoverOn = function() {
    $(this).addClass('article-hover');
//    $(this).height("+=58");
//    $(this).width("+=20");
//    $(this).css({
//      'padding-left': '10px',
//      'padding-top': '38px'
//    });
  }
  $.fn.articleHoverOff = function() {
    $(this).removeClass('article-hover');
//    $(this).height("auto");
//    $(this).width("auto");
//    $(this).css({
//      'padding-left': '0',
//      'padding-top': '0'
//    });
  }



  // ARTICLE INIT EVENTS
  // --------------------------------------------------
  $.fn.initArticleEvents = function(){
    // Broad initialization to articles
    var $allArticles = $(this);

    if( $('body').hasClass('index-page') ){
      $allArticles.hover(
        function(){
          $(this).articleHoverOn();
        }, function(){
          $(this).articleHoverOff();
        }
      );

      var hammer_options = {};

      // Open article on click
      $allArticles.hammer(hammer_options).on({ 'tap click': function(e){
        $(this).callArticle();
        $(this).articleHoverOff();
        e.stopPropagation();
        e.preventDefault();
        e.gesture.stopPropagation();
        e.gesture.preventDefault();
      } });

      $allArticles.find('a').click(function(e){
        $(this).callArticle();
        e.stopPropagation();
        e.preventDefault();
        e.gesture.stopPropagation();
        e.gesture.preventDefault();
      });

      // Open the viewer in the case where you click on the footer elements vs. overlay
      $allArticles.find('footer ul.meta a').click(function(e){
        var $article = $(this).closest('.article-box');
        $(this).callArticle();
        $article.articleHoverOff();
        e.stopPropagation();
        e.preventDefault();
        e.gesture.stopPropagation();
        e.gesture.preventDefault();
      });

    }

    // Specific initialization to articles
    return this.each(function (i){
      var $article = $(this);

    });
  }
  $('.article-box').initArticleEvents();

  // RESIZE EVENTS
  // --------------------------------------------------



  $('span.icon-search').click(function(e){
    var $form = $(this).parent().find('form');
    var $input = $(this).parent().find('input');
    var $icon = $(this);

    $icon.addClass('highlight');
    $form.animate({
      width: '158px'
    }, 300, 'easeInOutQuad');

    $input.focus();
    $input.blur(function(){
      $form.animate({
        width: '0px'
      }, 300, 'easeInOutQuad', function(){
        $icon.removeClass('highlight');
      });
    });
  });


  // ISOTOPE / CUSTOM LAYOUT
  // --------------------------------------------------


  if(window.screen.width > 586){
    $nav.scrollToFixed({
      baseClassName: 'locked',
      dontSetWidth: true,
      postFixed: function(){
        // leaving fixed
        $nav.css({
          'bottom': StyleHatch.navBottom
        })
      }
    });
  }


  var $posts = $('#posts').isotope({
    itemSelector: '.article-box',
    masonry: {
      columnWidth: 320,
      gutter: 16,
      isFitWidth: true
    },
    transitionDuration: 0
  });
  // layout Isotope again after images loaded
  $posts.imagesLoaded(function(){
    $posts.isotope('layout');
  });
  $('#posts article').resize(function(e){
    $posts.isotope('layout');
  });


  // INFINITE SCROLLING
  // --------------------------------------------------
  if(StyleHatch.infiniteScroll && StyleHatch.indexPage && !$('html').hasClass('ie6') && !$('html').hasClass('ie7') ){

    var pathName = window.location.pathname;
    var pathNameParts = pathName.split('/');
    var pathStructure;
    var pathCurrPage;
    if(pathName === '/'){
      // Normal first index page
      pathStructure = '/page/';
      pathCurrPage = 1;
    } else if (pathName.substring(0,6) === '/page/') {
      // Deep in index page, grab the current page number
      pathStructure = '/page/';
      pathCurrPage = parseInt(pathNameParts[2]);
    } else if(pathName.substring(0,8) === '/tagged/') {
      // Tagged page URLs, try to grab page number
      pathStructure = '/' + pathNameParts[1] + '/' + pathNameParts[2] + '/page/';
      try {
        if(typeof pathNameParts[3] === 'undefined'){
          // No page number exists, set to one
          pathCurrPage = 1;
        } else {
          // Use the current page number
          pathCurrPage = parseInt(pathNameParts[4]);
        }
      }
      catch(error) {
        log('Infinite scroll URL error');
      }
    }

    $('#posts').infinitescroll({

        navSelector  : '#infinite',
        nextSelector : '#infinite a',
        itemSelector : '.article-box',
        // path         : ['/page/', '/', '/tagged/'],
        path         : function(num){
          return pathStructure + num;
        },
        bufferPx     : 400,
        debug        : false,
        state        : {
          currPage   : pathCurrPage
        },
        errorCallback: function() {

            $('#infinite a').html(StyleHatch.noMoreText);
            $('#infinite').delay(1000).fadeOut(300);
            setTimeout(function(){
                $('#infinite').remove();
            }, 1300);

        }
    }, function(newElements, opts){
      /*
        History.js functionality
      */
      // get the current page
      var currPage = opts.state.currPage;
      // append the URL
      // TODO check if on day, tag or search page
      var newURL = pathStructure + currPage;
      StyleHatch.baseURL = newURL;

      // Set the history state
      if($('#posts').infinitescroll().data('infinitescroll').options.state.isPaused === false){
        History.pushState({state:currPage}, null, newURL);
      }

      // Add the posts to isotope
      $posts.append( $(newElements) ).isotope('appended', $(newElements));

      // Get the like button data
      Tumblr.LikeButton.get_status_by_page(currPage);

      if( $(newElements).length === 1 && $(newElements).hasClass('results') ){
        $('#infinite').delay(1000).fadeOut(300);
            setTimeout(function(){
                $('#infinite').remove();
            }, 1300);
      }

      //article loop to swap out audio player with flash
      $(newElements).each(function(){
          if($(this).hasClass('results')){
            $(this).remove();
          }
      });

      $(newElements).initArticle();
      $(newElements).initArticleEvents();

      $('.tumblr_video_container').remove();

      if(StyleHatch.disqusID){
        var disqus_shortname = StyleHatch.disqusID;
        (function () {
            var s = document.createElement('script'); s.async = true;
            s.type = 'text/javascript';
            s.src = 'http://' + disqus_shortname + '.disqus.com/count.js';
            (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
        }());
      }

    });

  }


  // VIEWER
  // --------------------------------------------------
  var $viewer = $('#viewer');
  var $viewerContainer = $('#viewerContainer');
  var $viewerArticle = $('#viewerContainer article');

  // Call to article, this triggers a History push state
  // The lightbox/viewer listens to the History state to determine what/when to show
  $.fn.callArticle = function(){
    var $article = $(this).find('article');
    //log('calling...', $article.attr('data-permalink'));
    // HTML5 History
    if(!$article.attr("data-permahash")){
      var permalink = $article.attr('data-permalink');
      var permahash = permalink.slice( permalink.indexOf("/", 7) );
      $article.attr("data-permahash", permahash);
    }
    var postURL = $article.attr('data-permahash');
    var postID = $article.attr('data-postid');

    // Push the state of the page, which triggeres the listener
    // and opens the post viewer
    History.pushState({
      id: postID
    }, null, postURL);
  }


  // load article
  $.fn.loadArticle = function(){
    $('#posts').infinitescroll('pause');

    var $article = $(this);

    if($article.length === 0){
      window.location = StyleHatch.url;
      return false;
    }

    // Unload the current article if one is already loaded
    if( $('body').hasClass('viewer-open') ){
      unloadArticle();
    }

    // Assign the current article to StyleHatch object
    StyleHatch.currentArticle = $(this);

    // Grab all the article contents
    var articleHeader = $article.find('header').html();
    var articleSection = $article.find('section').html();
    var articleFooter= $article.find('footer').html();
    var articleClasses = $article.attr('class');

    // Add attr data
    $viewerArticle.attr('data-postID', $article.attr('data-postID'));
    $viewerArticle.attr('data-permalink', $article.attr('data-permalink'));
    $viewerArticle.attr('data-reblog', $article.attr('data-reblog'));
    $viewerArticle.attr('data-permahash', $article.attr('data-permahash'));

    // Add the classes
    $viewerArticle[0].className = '';
    $viewerArticle.addClass(articleClasses);

    if($viewerArticle.attr('data-postID') !== ""){
      $viewerArticle.prepend('<footer>' + articleFooter + '</footer>');
    }
    $viewerArticle.prepend('<section>' + articleSection + '</section>');
    $viewerArticle.prepend('<header>' + articleHeader + '</header>');



    // Check the order of the articles and see if first or last
    checkArticleOrder($(this));

    // Add notes, disqus, share, tumblr bar
    if($viewerArticle.attr('data-postID') !== ""){

      //Load Disqus
      if(StyleHatch.disqusID !== ''){
        if(!window.DISQUS){
          $viewerArticle.append('<div id="disqus_thread"></div>');

          var disqus_shortname = StyleHatch.disqusID;
          var disqus_url = window.location.href;
          var disqus_identifier = $viewerArticle.attr('data-postID');
          (function() {
            var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
            dsq.src = 'http://' + disqus_shortname + '.disqus.com/embed.js';
            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
          })();
        } else {
          DISQUS.reset({
            reload: true,
            config: function () {
              this.page.identifier = $viewerArticle.attr('data-postID');
              this.page.url = window.location.href;
            }
          });
        }

      }

      // Load Notes
      var postNotesURL = $viewerArticle.find('.notes').attr('data-notesurl');
      StyleHatch.notesLoad = $.ajax({
        url: postNotesURL,
        timeout: 5000,
        success: function(data){
          $viewerArticle.append('<footer class="extra"><div class="notes-holder">' + data + '</div></footer>');
          $viewerArticle.find('ol.notes li').each(function(){
            var $action = $(this).find('.action');
            var $avatar = $(this).find('.avatar');

            var alt = $action.text().trim();
            var src = $avatar.attr('src');

            if(src){
              var newSrc = src.replace('_16.', '_48.');
              $avatar.attr('src', newSrc);
              $(this).find('a:first-child').attr('title', alt);
              $(this).find('a:first-child').attr('rel', 'tooltip');
              $avatar.attr('alt', alt);
            }
          });
        }
      });

      // Share buttons
      var $shareButtons = $viewerArticle.find('.share-buttons');
      $shareButtons.attr('data-permalink', $viewerArticle.attr('data-permalink'));
      $shareButtons.setupTumblrShare();

      // Open 'read more' link on text posts
      var $readMore = $viewerArticle.find('section a.read-more');
      if($readMore.length > 0){
        // Add loading spinner
        $readMore.replaceWith('<span id="readmore-spin"></span>');
        var target = document.getElementById('readmore-spin');
        //var readmoreSpinner = new Spinner(opts).spin(target);

        // Get the read more link
        var readMoreURL = $readMore.attr('href');

        $.ajax({
          url: readMoreURL,
          dataType: 'html',
          timeout: 5000,
          success: function(data){
            data = '<div>' + data + '</div>';
            var $articleSection = $(data).find('#posts article section')[0];
            $viewerArticle.find('section').replaceWith($articleSection);
          }
        });
      }

      // Change the Tumblr control bar
      StyleHatch.articleSrc = encodeURIComponent($viewerArticle.attr('data-permalink'));
      StyleHatch.articlePid = $viewerArticle.attr('data-postid');
      // get reblog key
      var reblog = $viewerArticle.attr('data-reblog');
      StyleHatch.articleRk = reblog.slice(-8);

      StyleHatch.tumblrControlsSrc = $('.tumblr_controls').attr('src');

      if(StyleHatch.tumblrControlsSrc){
        StyleHatch.articleLang = window.getQueryVariable(StyleHatch.tumblrControlsSrc, 'lang');
        StyleHatch.articleName = window.getQueryVariable(StyleHatch.tumblrControlsSrc, 'name');

        var tumblrSrc  = 'http://assets.tumblr.com/assets/html/iframe/o.html?src=' + StyleHatch.articleSrc + '&pid=' + StyleHatch.articlePid + '&rk=' + StyleHatch.articleRk + '&lang=' + StyleHatch.articleLang + '&name=' + StyleHatch.articleName;

        // Clone and append the controls to prevent double history entry
        var $newTumblrControl = $('#tumblr_controls').clone();
        $newTumblrControl.attr('src', tumblrSrc);
        $('#tumblr_controls').remove();
        $('body').append($newTumblrControl);

      }


    }

    openViewer();

  }

  // Open Viewer
  function openViewer(){
    // if not already open
    $viewer.show();

    $viewerArticle.initArticle();

    // if user hasn't scrolled below nav do it
    if($(window).scrollTop() < $('nav.pages').offset().top){
      $(window).scrollTop($('nav.pages').offset().top);
    }

    // Add margin below
    $(window).resize(function(e){
      if(!StyleHatch.indexPage){
        var windowHeight = $(window).height();
        var viewerHeight = $('#viewerContainer').outerHeight();
        var viewerTop = parseInt( $('.viewerCell').css('padding-top').replace('px', '') );
        var navHeight = $('nav.pages').outerHeight();

        var viewerBottom = windowHeight - viewerHeight - viewerTop - navHeight;
        if(viewerBottom > 0){
          $('#viewerContainer').css('margin-bottom', viewerBottom);
        }
      }
    });
    $(window).resize();

    if($('body').hasClass('permalink-page')){
      $(window).scrollTop($('nav.pages').offset().top);
    }

    // lock the primary scroll bar and enable the overview one
    lockScroll();
  }

  // Unload Article
  function unloadArticle(){
    $('#posts').infinitescroll('resume');
    // remove the guts of the article - header, section, footer
    $viewerArticle.find('header').remove();
    $viewerArticle.find('section').remove();
    $viewerArticle.find('footer').remove();

    StyleHatch.currentArticle = null;

    // Stop the loading of the notes if in progress
    if(StyleHatch.notesLoad){
      StyleHatch.notesLoad.abort();
    }

    // Reset the Tumblr controls
    if(StyleHatch.tumblrControlsSrc){
      // Clone and append the controls to prevent double history entry
      var $newTumblrControl = $('#tumblr_controls').clone();
      $newTumblrControl.attr('src', StyleHatch.tumblrControlsSrc);
      $('#tumblr_controls').remove();
      $('body').append($newTumblrControl);
    }
  }

  // next article
  function nextArticle(){
    var articleIndex = $('#posts article').index(StyleHatch.currentArticle);
    var $nextArticle = $('#posts article').eq(articleIndex + 1);
    $nextArticle.parent().callArticle();
  }
  // prev article
  function prevArticle(){
    var articleIndex = $('#posts article').index(StyleHatch.currentArticle);
    var $prevArticle = $('#posts article').eq(articleIndex - 1);
    $prevArticle.parent().callArticle();
  }

  $('.viewerPrev a').click(function(e){
      if(StyleHatch.indexPage === true){
          prevArticle();
          e.preventDefault();
      }
  });
  $('.viewerNext a').click(function(e){
      if(StyleHatch.indexPage === true){
          nextArticle();
          e.preventDefault();
      }
  });

  StyleHatch.enableKeyNext = true;
  StyleHatch.enableKeyPrev = true;
  // Keyboard next/prev
  $(document).jkey('j',function(){
      if(StyleHatch.currentArticle && StyleHatch.enableKeyPrev && StyleHatch.indexPage){
          prevArticle();
      } else if (!StyleHatch.indexPage){
        if($('.viewerPrev a').attr('href') !== '#'){
          window.location = $('.viewerPrev a').attr('href');
        }
      }

  });
  // Keyboard next/prev
  $(document).jkey('k',function(){
      if(StyleHatch.currentArticle && StyleHatch.enableKeyNext && StyleHatch.indexPage){
          nextArticle();
      } else if (!StyleHatch.indexPage){
        if($('.viewerNext a').attr('href') !== '#'){
          window.location = $('.viewerNext a').attr('href');
        }
      }
  });
  // Check to see if the article is the first or last in the list
  function checkArticleOrder($article){
      if(StyleHatch.indexPage === true){
          var articleIndex = $('#posts article').index($article);
          var articleIndexMax = $('#posts article').length;
          if(articleIndex === 0){
              $('.viewerPrev').hide();
              StyleHatch.enableKeyPrev = false;
          } else {
              $('.viewerPrev').show();
              StyleHatch.enableKeyPrev = true;
          }
          if(articleIndex === (articleIndexMax-1)){
              // TODO - first try to load next page
              $('.viewerNext').hide();
              StyleHatch.enableKeyNext = false;
          } else {
              $('.viewerNext').show();
              StyleHatch.enableKeyNext = true;
          }
      } else {
          var prevURL = $('#pagination li.prev.active a').attr('href');
          var nextURL = $('#pagination li.next.active a').attr('href');

          if(nextURL !== undefined){
              $('.viewerPrev a').attr('href', nextURL);
          } else {
              $('.viewerPrev').hide();
          }

          if(prevURL !== undefined){
              $('.viewerNext a').attr('href', prevURL);
          } else {
              $('.viewerNext').hide();
          }
      }

  }

  function closeViewer(){
    unloadArticle();
    unlockScroll();
    $viewer.hide();
  }

  var hammer_options = {};

  $viewer.hammer(hammer_options).on({'swiperight click': function(){
    if(StyleHatch.indexPage === true){
      History.pushState(null, null, StyleHatch.baseURL);
    }
    // else {
    //   window.location = '/';
    // }
  } });
  $viewer.find('#viewerContainer, .viewerPrev a, .viewerNext a').click(function(e){
    e.stopPropagation();
  });

  // Lock/Unlock scrollbar on body and viewer
  function lockScroll(){
    $viewer.scrollTop(0);
    $('body').addClass('viewer-open');
  }
  function unlockScroll(){
    $viewer.scrollTop(0);
    $('body').removeClass('viewer-open');
  }

  // PERMALINK PAGES
  // --------------------------------------------------
  if(StyleHatch.indexPage === false){
    var $permalinkArticle = $('#posts article');
    $permalinkArticle.loadArticle();
  }

  // LOAD EXTERNAL DATA
  // --------------------------------------------------
  //Instagram integration
  StyleHatch.instagramCount = 1;
  if(StyleHatch.instagramToken){
      $.ajax({
      url: "https://api.instagram.com/v1/users/self/media/recent/?access_token=" + StyleHatch.instagramToken + "&count=" + StyleHatch.instagramCount,
      dataType: "jsonp",
      timeout: 5000,
      success: function(data) {
        for (var i = 0; i < StyleHatch.instagramCount; i++) {
          var image = data.data[i].images.low_resolution.url;
          var link = data.data[i].link;
          var likes = data.data[i].likes.count;
          var comments = data.data[i].comments.count;
          var caption = '';
          if(data.data[i].caption){
            caption = data.data[i].caption.text;
          }

          // Add the image and link
          $('section.instagram .shot-holder').html('<a href="' + link + '" target="_blank"><img src="' + image + '" height="320" width="320" /></a>');
          // Add the caption
          if(data.data[i].caption){
            $('section.instagram .shot-caption').html('<p>' + caption + '</p>');
          }
          // Add the icon label values
          $('section.instagram .meta li.likes a').html(likes);
          $('section.instagram .meta li.comments a').html(comments);

          // Add links to the icons
          $('section.instagram .meta li.likes a, section.instagram .meta li.comments a').attr('href', link).attr('target', '_blank');

        }
        var instagramFeed = 'http://www.instagram.com/' + data.data[0].user.username;
        $('section.instagram h4 a, section.instagram .meta li.link a').attr('href', instagramFeed);
        $('section.instagram h4 a, section.instagram .meta li.link a').attr('target', '_blank');
      }
      });
  }


  // CUSTOMIZE MENU
  // --------------------------------------------------

  // if(StyleHatch.customizeMode){
  //   $('section.liked-posts').hide();
  //   $('.audio_player').addClass('customize-audio black');
  //   $('.fluid-width-video-wrapper').addClass('customize-embed');
  // }

})( window, jQuery );