// jQuery Tumblr Share Plugin
// version 0.1, April 2, 2011
// by Jonathan Moore - http://jonathanmoore.com
// Plugin architecture based on jQuery Plugin Boilerplate - http://stefangabos.ro/jquery/jquery-plugin-boilerplate-revisited/

(function($) {

    // here we go!
    $.tumblrShare = function(element, options) {

        var defaults = {
			url: '',
			title: '',
			media: '',
			via: '',

            twitter: true,
			facebook: true,
			gplus: true,
			pinterest: false,
			
			size: 'horizontal',

            // overwritable events that can be called w/ plugin
            onInit: function() {},
			onComplete: function() {}
        };

        var plugin = this;

        // plugin.settings.propertyName from inside the plugin or
        // element.data('tumblrShare').settings.propertyName from outside the plugin
        plugin.settings = {};

        var $element = $(element),  // reference to the jQuery version of DOM element
             element = element;     // reference to the actual DOM element

        plugin.init = function() {
            plugin.settings = $.extend({}, defaults, options);

            // Event is overridable in the contructor
			plugin.settings.onInit();
			
			var encodeUrl = encodeURIComponent(plugin.settings.url);
			var encodeMedia = encodeURIComponent(plugin.settings.media);
			
			// Twitter
			if(plugin.settings.twitter){
				var $twitterWrap = $('<div class="share-button share-twitter"></div>');
				var $twitterBtn = $('<a href="http://twitter.com/share" class="twitter-share-button" data-url="' + plugin.settings.url + '" data-via=' + plugin.settings.via + '></a>');
				// set layout style
				if(plugin.settings.size == "horizontal"){
					$twitterBtn.attr('data-count', 'horizontal');
				}
				if(plugin.settings.size == "vertical"){
					$twitterBtn.attr('data-count', 'vertical');
				}
				
				$twitterWrap.append($twitterBtn);
				$element.append($twitterWrap);
			}
			
			// Facebook
			if(plugin.settings.facebook){
				var $facebookWrap = $('<div class="share-button share-facebook"></div>');
				// set layout style
				if(plugin.settings.size == "horizontal"){
					var $facebookBtn = $('<iframe src="http://www.facebook.com/plugins/like.php?href=' + encodeUrl + '&amp;send=false&amp;layout=button_count&amp;width=90&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=21&amp;" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:90px; height:21px;" allowTransparency="true"></iframe>');
				
				}
				if(plugin.settings.size == "vertical"){
					var $facebookBtn = $('<iframe src="http://www.facebook.com/plugins/like.php?href=' + encodeUrl + '&amp;send=false&amp;layout=box_count&amp;show_faces=false&amp;action=like&amp;font=lucida+grande&amp;colorscheme=light&amp;height=65&amp;width=55" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:65px;" allowTransparency="true"></iframe>');
				}
				
				$facebookWrap.append($facebookBtn);
				$element.append($facebookWrap);
			}
			
			// Google Plus
			if(plugin.settings.gplus){
				var $gplusWrap = $('<div class="share-button share-gplus"></div>');
				var $gplusBtn = $('<g:plusone href="' + plugin.settings.url + '"></g:plusone>');
				
				// set layout style
				if(plugin.settings.size == "horizontal"){
					$gplusBtn.attr('size', 'medium');
				}
				if(plugin.settings.size == "vertical"){
					$gplusBtn.attr('size', 'tall');
				}
				
				$gplusWrap.append($gplusBtn);
				$element.append($gplusWrap);
			}
			
			// Pinterest
			if(plugin.settings.pinterest){
				var $pinterestWrap = $('<div class="share-button share-pinterest"></div>');
				var $pinterestBtn = $('<a href="http://pinterest.com/pin/create/button/?url=' + encodeUrl + '&media=' + encodeMedia + '" class="pin-it-button"><img border="0" src="//assets.pinterest.com/images/PinExt.png" title="Pin It" /></a>');
				
				// set layout style
				if(plugin.settings.size == "horizontal"){
					$pinterestBtn.attr('count-layout', 'horizontal');
				}
				if(plugin.settings.size == "vertical"){
					$pinterestBtn.attr('count-layout', 'vertical');
				}
				
				$pinterestWrap.append($pinterestBtn);
				$element.append($pinterestWrap);
			}
			
			
			// event triggered after the plugin is complete
			plugin.settings.onComplete();
        };


        // fire up the plugin!
        // call the "constructor" method
        plugin.init();

    };

    $.fn.tumblrShare = function(options) {

        return this.each(function() {

            if (undefined === $(this).data('tumblrShare')) {

                var plugin = new $.tumblrShare(this, options);

                // you can later access the plugin and its methods and properties like
                // element.data('tumblrPhotoset').publicMethod(arg1, arg2, ... argn) or
                // element.data('tumblrPhotoset').settings.propertyName
                $(this).data('tumblrShare', plugin);

            }

        });

    };

})(jQuery);
