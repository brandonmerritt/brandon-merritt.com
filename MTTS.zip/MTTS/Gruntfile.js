'use strict';


module.exports = function(grunt) {

  // Project config
  /* SET - theme name, description and version number
  **/
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),


    connect: {
      server: {
        options: {
          port: 9001
        }
      }
    },

    // Opens up the browser to the localhost along with the port defined above
    open: {
      dev: {
        path: 'http://127.0.0.1:<%= connect.server.options.port %>/'
      }
    },

    // Observe the js/html/css files for changes and execute the tasks
    watch: {
      options: {
        livereload: true,
      },
      app: {
        files: ['js/app/**/*.js'],
        tasks: ['jshint', 'concat:app'],
      },
      plugins: {
        files: ['js/plugins/**/*.js'],
        tasks: ['concat:plugins'],
      },
      html: {
        files: '**/*.html'
      },
      tumblr: {
        files: '**/*.html.tumblr'
      },
      scss: {
        files: '**/*.scss',
        tasks: ['sass']
      }
    },

    // Check for ghetto js in the plugin
    jshint: {
      // options: {
      //   curly: true,
      //   eqeqeq: true,
      //   eqnull: true,
      //   browser: true,
      //   globals: {
      //     "jQuery": true,
      //     "StyleHatch": true,
      //     "log": true
      //   },
      // },
      dest: ['js/app/**/*.js']
    },

    // Minify the file and add a comment banner at the top with settings from package.json
    uglify: {
      options: {
        banner: '/**\n' +
          ' * <%= pkg.name %> - v<%= pkg.version %>\n' +
          ' * <%= grunt.template.today("yyyy-mm-dd") %>\n' +
          ' * <%= pkg.links.demo %>\n' +
          ' *\n' +
          ' * Copyright <%= grunt.template.today("yyyy") %> <%= pkg.author %>\n' +
          ' */\n'
      },
      script: {
        files: {
          'js/script.min.js': ['js/script.js']
        }
      },
      plugins: {
        files: {
          'js/plugins.min.js': ['js/plugins.js']
        }
      }
    },

    // Use concat for the server command for speed and debugging
    concat: {
      app: {
        src: ['js/app/**/*.js'],
        dest: 'js/script.js'
      },
      plugins: {
        src: ['js/plugins/**/*.js'],
        dest: 'js/plugins.js'
      }
    },

    sass: {
      dist: {
        options: {
          style: 'compact'
        },
        files: {
          'css/theme.css': 'scss/theme.scss'
        }
      }
    }


  });

  // Load the grunt plugins
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-contrib-connect');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-sass');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-open');

  // $ grunt
  // Checks the js and minifies it
  grunt.registerTask('default', ['sass', 'jshint', 'concat', 'uglify']);
  // $ grunt server
  // Checks the js, minfies it, starts watch, connects to a local server, opens the browser and watches for changes
  grunt.registerTask('server', ['default', 'connect', 'watch']);

};