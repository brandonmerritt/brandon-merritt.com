# Pacific Grid

Getting Started
---------------

`pacificgrid` depends on [Node.js](http://nodejs.org/) and [npm](http://npmjs.org/). Additionally if you want to use Scss you will need to make sure you have [Ruby](http://www.ruby-lang.org/en/downloads/) and [Sass](http://sass-lang.com/download.html) installed.

##### Use npm to download all of the build dependencies

```sh
$ npm install
```

Usage
-----

The `Gruntfile.js` file defines the tasks to your build scss and js.  By default the build files will exist in the following directories:

* SCSS - `/scss/`
* JavaScript - `/js/app/stylehatch.js`
* JavaScript Plugins - `/js/plugins/**/*.js`

##### Run all tasks, default
```sh
$ grunt
```

##### Watch for changes to run tasks and livereload
```sh
$ grunt watch
```

Local Development
-----
When you are actively editing the JavaScript and SCSS files it works best to modify the pacificgrid.html.tumblr file to point the sources to the local server Grunt creates.

```html
  <link rel="stylesheet" href="http://127.0.0.1/css/theme.css">

  <!-- ... -->

  <script src="http://127.0.0.1/js/plugins.js"></script>
  <script src="http://127.0.0.1/js/script.js"></script>
```

Once you have pointed the CSS and JS files to the local server you can copy and paste the theme code into the Tumblr Customize menu.  At this point you can enable the [LiveReload extension](https://chrome.google.com/webstore/detail/livereload/jnihajbhpnppcggbcgedagnkighmdlei?hl=en) to have `grunt watch` update changes.

Once the JS and CSS files are finalized you can manually upload them to Tumblr at http://www.tumblr.com/themes/upload_static_file

[Tumblr Theme Documenation](http://www.tumblr.com/docs/en/custom_themes)

## Introducing Pacific Grid

Pacific Grid is a highly visual theme that puts your content at the center stage. With the flexible grid layout and post overlay your visitors will find it easy to quickly browse through your posts.  Also, the theme's full browser profile makes Pacific Grid your perfect home on the internet.  Pacific Grid is perfect for blogs, portfolios, and currated inspiration. 

- Full-screen header profile for yourself, blog or business
- Change the postition of your header profile
- Grid layout with quick reblog and like buttons
- Post overlay to quickly view your posts from the grid
- Extended color controls to make the color scheme your own
- Built in support for Tumblr's font library
- Comments powered by Disqus
- Google Analytics ready
- Popular social icons

## Theme Features

### Header Profile

The full-screen header on Pacific Grid works perfectly for your new home on the internet. You can upload a picture of yourself in the background, add a loog, customize your description, and add social links.

### Post Viewer

Clicking on a post in the grid will instantly overlay the full post with notes, comments and post details. To quickly go between your posts you can click on the next and previous links or hit "j" and "k" on the keyboard.

### Social Features

The theme has built in support for group blogs, sharing on Facebook, Twitter, Pinterest, and Google \+, comments by Disqus, and sites you follow. In the Appearances options you’ll also find a variety of the most popular social profile icon links.

### Extended Styling Options

Pacific Grid gives you color options to control the look of virtualy every element in the theme. Show off your inner genius and create a unique look and feel to your blog that's unlike any other!

### Responsive Design

The types of devices and ways that people are viewing your blog are growing exponentially, so having a layout for your blog that adapts from the largest resolution monitors down to mobile views is important. Go ahead and try it out, go to the demo site and resize your browser window down to get an idea of how the layout changes.

## Customization Options

### Images

- **Header Logo -** Upload an image to replace the blog title in the header profile. For the best look, upload a transparent PNG logo that matches or complements the theme’s text color.
- **Header Background -** The background image you upload will fill the entire browser window behind your title, description and social icons.  A great resource for background images is [unsplash.com](http://unsplash.com/).


### Colors

- **Header Background -** Changes the color of the background in the full-browser header. If you have a Header Image uploaded you need to clear it out to see the background color.
- **Header Text -** Changes the color of the title, description and small text in the header.
- **Header Accent -** Changes the color for links in the header.
- **Header Accent Hover -** Changes the color while hovering over links in the header.
- **Navigation Background -** Changes the background color of the navigation barl
- **Navigation Title -** Changes the color of the title at the top left of the navigation barl
- **Navigation Accent -** Changes the color of the page links in the navigation.
- **Navigation Accent Hover -** Changes the color while hovering over the page links.
- **Site Background -** Changes the overall background color behind the grid.
- **Post Background -** Changes the background color of the post box both in the grid and post viewer.
- **Post Text -** Changes the text color for the posts.
- **Post Accent -** Changes the color of links, Quote, and Link post backgrounds.
- **Post Accent Inverse -** Changes the color of text that appears on top of the accent color.
- **Post Accent Hover -** Changes the color while you hover over the links, additionally it is used for the pagination and loading bar at the bottom of the blog.
- **Post Subtle -** Changes the subtle grey color used in the theme for notes count, post details, tags, etc.
- **Viewer Overlay -** Changes the transparent background that you see behind the post viewer.

### Fonts

- **Body Font, Title Font, UI Font -** Choose from the list of fonts that Tumblr supports on their blogs.
- **Use Recommended Fonts -** By default we are loading in the fonts that we think look best with Pacific Grid. If you want to select your own, make sure you turn this option off.


### Options

- **Header Layout -** Choose from top left, top right, center, bottom left, and bottom right for the position of your title, description and social icons.
- **Twitter Follow Alignment -** If you set the Header Layout to the right you will want to change the alignment of the Twitter follow button to the right.
- **Fill Header Background -** Turn this option off if you want to tile the header background image.
- **Infinite Scrolling -** Allows your theme to automatically load page after page of posts as you scroll.
- **Twitter Follow Button -** If you have Twitter set up in your Tumblr settings this option will automatically load in the follow button.


### Additional Options

- **Disqus ID -** Add your Disqus Site Shortname to enable comments for your site. [Click here to register for a Disqus site account](http://disqus.com/admin/register/).
- **Google Analytics ID -** Google Analytics tracking is built right into the theme, all you need to do is add your site ID to this option.
- **Clicky ID -** For realtime tracking of who is on your site right now, goals, campaigns and Twitter monitoring add your Clicky ID. Clicky does charge for their analytics and tracking, but I highly recommend it for people who are stats junkies. [Sign up for an account with Clicky](http://getclicky.com/144476).
- **Webfont Embed -** If you want to use fonts from Typekit, Google Fonts or other online font hosting services paste in the provided embed code.
- **Body/Title/UI Font Family -** Add the list of font families for the overall body, title and UI fonts.

### Social Links

Add your URLs to display the corresponding social site's icon as a link. *Note: Make sure you add the full URL, including “http://”.*

*Current List of Supported Icons*
500px, Bandcamp, Behance, Cargo Collective, Delicious, Dribbble, Etsy, Facebook, Flickr, Foursquare, Gimmie Bar, Github, Google Plus, Instagram, Last.fm, LinkedIn, Pinterest, Quora, Rdio, Reddit, Soundcloud, Spotify, Stumbled Upon, Tumblr, Vimeo, YouTube, Website, Store, Email Address

For Support email us at [support@stylehatch.co](mailto:support@stylehatch.co)
